﻿using System;

namespace OverrideVsNew
{
    public class Animal
    {
        public virtual string Sound()
        {
            return "Sound will be ";
        }
    }
}
