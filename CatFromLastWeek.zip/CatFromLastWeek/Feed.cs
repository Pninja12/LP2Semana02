namespace CatFromLastWeek
{
    public enum Feed
    {
        Starving,
        Hungry,
        Satisfied,
        Full,
        AboutToExplode
    }
}
